## Module <hrms_dashboard>
#### 01.10.2024
#### Version 18.0.1.0.0
##### ADD
- Initial commit for Open HRMS dashboard

#### 01.08.2025
#### Version 18.0.1.1.0
##### UPDATE
- Updated project details displayed on the dashboard
- Fixed styling errors in the dashboard UI
